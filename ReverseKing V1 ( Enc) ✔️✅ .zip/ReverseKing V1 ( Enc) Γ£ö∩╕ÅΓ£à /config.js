require("./database/module")

//GLOBAL PAYMENT
global.storename = "𝑹𝑬𝑽𝑬𝑹𝑺𝑬 𝑲𝑰𝑵𝑮-𝑽1"
global.dana = "233542680612"
global.qris = "https://files.catbox.moe/4rycos.jpg"


// GLOBAL SETTING
global.owner = "23354xxxxxxxx"
global.namabot = "𝑹𝑬𝑽𝑬𝑹𝑺𝑬 𝑲𝑰𝑵𝑮-𝑽1"
global.nomorbot = "23354xxxxxxxx"
global.namacreator = "𝑹𝑬𝑽𝑬𝑹𝑺𝑬 𝑲𝑰𝑵𝑮 ϟ"
global.linkyt = false
global.autoJoin = false
global.antilink = false
global.versisc = 'V1'

// DELAY JPM
global.delayjpm = 5500

// SETTING PANEL
global.apikey = 'plta_JGstZXVOB9lnibEyep1BwC9MSxPvAT5mFcbiEHLSHUv'
global.capikey = 'pltc_NLgcXEXYq3clwqgaetEPk97l26afklOhjh67sJQvQsF'
global.domain = 'https://'
global.eggsnya = '15'
global.location = '1'



//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = 'https://files.catbox.moe/4rycos.jpg'
global.isLink = 'https://whatsapp.com/channel/0029Vao11A529758tTEQZo1e'
global.packname = "𝑹𝑬𝑽𝑬𝑹𝑺𝑬 𝑲𝑰𝑵𝑮-𝑽1"
global.author = "𝑹𝑬𝑽𝑬𝑹𝑺𝑬 𝑲𝑰𝑵𝑮"
global.jumlah = "5"

//MESS
global.mess = {
    success: '✔ Done Nigga! 😂',
    admin: '_*🤟This Shit can only be used by group admins or by 𝑹𝑬𝑽𝑬𝑹𝑺𝑬 𝑲𝑰𝑵𝑮!*_',
    botAdmin: '_*💀This Shit can only be used when the bot is a group admin or 𝑹𝑬𝑽𝑬𝑹𝑺𝑬 𝑲𝑰𝑵𝑮!*_',
    OnlyOwner: '_*💀This Shit can only be used by 𝑹𝑬𝑽𝑬𝑹𝑺𝑬 𝑲𝑰𝑵𝑮!*_',
    OnlyGrup: '_*💀This Shit can only be used in group chats or by 𝑹𝑬𝑽𝑬𝑹𝑺𝑬 𝑲𝑰𝑵𝑮!*_',
    private: '_This Shit can only be used in private chat or by 𝑹𝑬𝑽𝑬𝑹𝑺𝑬 𝑲𝑰𝑵𝑮!*_',
    wait: '_*Please Wait, Your Request Is Being Proceed*_',
    notregist: '_*You are not yet registered in the bot database, please contact 𝑹𝑬𝑽𝑬𝑹𝑺𝑬 𝑲𝑰𝑵𝑮!*_',
    premium: '_*Premium users only! Buy Premium from  ‪+233542680612‬ or type .owner*_',
    endLimit: '_*Bro Your Daily Limit Has Expired!\nLimit Will Be Reset Every Time 00:00 WIB or By Buying Premium and Get Unlimited Limit\nBuy Prem? Chat ‪+233542680612‬*_',
    maintenance: '_*Sorry my gee, this feature is currently under construction*_',
    wait: 'Wait a minute, bro...',
    error: 'Wow, this is an error'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})